CREATION MODE — Official badges, modedecreation.org (framework 1.3)

Contents
- 3 full-size badges (PNG, transparent background): preferred whenever the text stays readable (about 160 px and up).
- 3 mini badges (PNG, transparent background): for 96 px and below, always with a written label next to them.
- The 1.3 framework (PDF), including the usage guidelines.

Reminders
- Green = Human production; blue = AI-assisted production; purple = AI-generated production.
- Do not distort, rotate, crop or alter the badges.
- A badge is a voluntary self-declaration, never a certification.

https://modedecreation.org/en/
